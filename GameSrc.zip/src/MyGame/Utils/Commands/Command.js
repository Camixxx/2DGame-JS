"use strict";  

// Constructor
function Command() {}


Command.prototype.excute = function(){};